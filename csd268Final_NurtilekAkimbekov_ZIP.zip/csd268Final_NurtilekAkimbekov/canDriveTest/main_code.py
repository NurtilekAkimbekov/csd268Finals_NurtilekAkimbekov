def can_drive(age):
    driving_age = 16
    return age >= driving_age
